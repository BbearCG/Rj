# Rj (GitHub Pages)

ไฟล์สำหรับเปิดใช้งาน GitHub Pages ให้ลิงก์กดแล้วไปหน้าโพสต์ทวีต

## โครงสร้างไฟล์
- index.html  ← หน้าเว็บหลัก
- .nojekyll   ← ปิดการประมวลผล Jekyll (กัน edge case)

## วิธีเปิดใช้งาน GitHub Pages
1) อัปโหลดไฟล์ทั้งหมดไปยัง repo (โฟลเดอร์รากของ branch)
2) ไปที่ Settings → Pages
3) Build and deployment:
   - Source: Deploy from a branch
   - Branch: main
   - Folder: /(root)
   - Save
4) รอสักครู่จนขึ้นลิงก์ เช่น https://<username>.github.io/Rj/
5) เปิดลิงก์ทดสอบที่ https://<username>.github.io/Rj/index.html (ช่วยยืนยันได้แม้หน้าแรกยังแคช)

## Troubleshoot
- ถ้า 404: ตรวจสอบว่า repo เป็น Public, มี index.html ใน root, และ URL ตัวพิมพ์เล็ก/ใหญ่ตรงกับชื่อ repo
- ถ้ายังไม่ขึ้น ลองแก้ไฟล์เล็กน้อยแล้ว commit ใหม่ เพื่อกระตุ้น deploy
- ตรวจดูแท็บ Actions ว่ามีงาน “pages build and deployment” error หรือไม่
